﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JWTToken.Models
{
    public class Common
    {
        public class AppSettings
        {
            public string Secret { get; set; }
        }

        public class User
        {
            public int Userid { get; set; }
            public string Username { get; set; }
            public string Password { get; set; }

        }

        public class UserViewModel : User
        {
            public string Token { get; set; }
        }
    }
}
