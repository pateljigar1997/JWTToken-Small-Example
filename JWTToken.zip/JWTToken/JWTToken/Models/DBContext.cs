﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JWTToken.Models;

namespace JWTToken.Models
{
    public class DBContext:DbContext
    {
        public DBContext(DbContextOptions options)
            : base(options)
        {

        }

        public DbSet<Common.User> User { get; set; }
    }
}
