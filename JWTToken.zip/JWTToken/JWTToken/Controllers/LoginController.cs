﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static JWTToken.Models.Common;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using JWTToken.Models;

namespace JWTToken.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly AppSettings _appSettings;
        private readonly DBContext _dBContext;

        public LoginController(IOptions<AppSettings> appSettings,DBContext dBContext)
        {
            _appSettings = appSettings.Value;
            _dBContext = dBContext;
        }

        [HttpPost]
        public IActionResult Login(User user)
        {
            
            var userisExist = _dBContext.User.Where(a => a.Username == user.Username && a.Password==user.Password).FirstOrDefault();
            UserViewModel userView = new UserViewModel();
            
            try
            {
                if (userisExist != null)
                {
                    string tokenValue = userisExist.Username + "||" + Convert.ToString(userisExist.Userid);
                    var tokenHandler = new JwtSecurityTokenHandler();
                    var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
                    var tokenDescriptor = new SecurityTokenDescriptor
                    {
                        Subject = new ClaimsIdentity(new Claim[]
                        {
                            new Claim(ClaimTypes.Name, tokenValue),
                            //new Claim(ClaimTypes.Role, roles[0])
                        }),
                        Expires = DateTime.UtcNow.AddDays(7),
                        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                    };
                    string token = tokenHandler.WriteToken(tokenHandler.CreateToken(tokenDescriptor));

                    if (!string.IsNullOrEmpty(token))
                    {
                        userView.Token = token;
                        userView.Password = "";
                    }
                    return StatusCode(200, userView);
                }
                else
                {
                    return StatusCode(404, "Not found record");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(404, ex.Message);
            }

        }
    }
}
