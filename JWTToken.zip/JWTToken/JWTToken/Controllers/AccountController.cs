﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JWTToken.Models;
using static JWTToken.Models.Common;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;

namespace JWTToken.Controllers
{
    
    public class AccountController : Controller
    {
        private readonly AppSettings _appSettings;

        public AccountController(IOptions<AppSettings> appSettings)
        {
            _appSettings = appSettings.Value;
        }
        public IActionResult Login()
        {
            User objuser = new User();

            string tokenValue = objuser.Username + "||" + Convert.ToString(objuser.Userid);
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                            new Claim(ClaimTypes.Name, tokenValue),
                            //new Claim(ClaimTypes.Role, roles[0])
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            string token = tokenHandler.WriteToken(tokenHandler.CreateToken(tokenDescriptor));

            if (!string.IsNullOrEmpty(token))
            {
                objuser.Username = token;
                objuser.Password = "";
            }
            return View();

        }
    }
}
